---
name: Kinetic Obsidian
colors:
  surface: '#121316'
  surface-dim: '#121316'
  surface-bright: '#38393c'
  surface-container-lowest: '#0d0e11'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#292a2d'
  surface-container-highest: '#343538'
  on-surface: '#e3e2e6'
  on-surface-variant: '#c5c9ac'
  inverse-surface: '#e3e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#8f9378'
  outline-variant: '#444932'
  surface-tint: '#b0d500'
  primary: '#ffffff'
  on-primary: '#2a3400'
  primary-container: '#caf300'
  on-primary-container: '#596c00'
  inverse-primary: '#536600'
  secondary: '#5de6ff'
  on-secondary: '#00363e'
  secondary-container: '#00cbe6'
  on-secondary-container: '#00515d'
  tertiary: '#ffffff'
  on-tertiary: '#003824'
  tertiary-container: '#6ffbbe'
  on-tertiary-container: '#00734e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#caf300'
  primary-fixed-dim: '#b0d500'
  on-primary-fixed: '#171e00'
  on-primary-fixed-variant: '#3e4c00'
  secondary-fixed: '#a2eeff'
  secondary-fixed-dim: '#2fd9f4'
  on-secondary-fixed: '#001f25'
  on-secondary-fixed-variant: '#004e5a'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#121316'
  on-background: '#e3e2e6'
  surface-variant: '#343538'
  surface-canvas: '#0B0C0E'
  surface-card: '#16181D'
  surface-card-elevated: '#1E2127'
  surface-highlight: '#272B33'
  border-subtle: '#262930'
  border-strong: '#3A3F4B'
  text-primary: '#F3F4F6'
  text-secondary: '#9CA3AF'
  text-muted: '#6B7280'
  status-success: '#10B981'
  status-warning: '#F59E0B'
  status-danger: '#EF4444'
  volt-glow: '#D4FF0026'
  emerald-glow: '#10B98126'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-timer:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  data-tabular:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: 0.02em
  data-tabular-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.5rem
  margin: 1rem
  margin-screen: 1.25rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system delivers a high-performance, precision-grade gym companion engineered specifically for one-handed operation under strenuous conditions. Built for athletes who prioritize focus and cadence over gamification, social feeds, or visual noise, the aesthetic is **Athletic Utilitarian Minimalism**.

### Core Tenets
- **Glanceability Under Fatigue:** Immediate legibility from arm’s length under harsh fluorescent gym lighting or dim strength caves. High-contrast typography and unambiguous status indicators eliminate visual hesitation.
- **Utilitarian Speed:** Frictionless logging with massive tap targets (minimum 48px, standard 56px for critical interactions) positioned within the natural one-handed thumb zone. Zero decorative bloat or deep nested navigation during live workouts.
- **Tactile Precision:** Physical, digital stopwatch clarity. Visual containers mimic precision timing gear and industrial instrument panels with crisp hairline contours, dense tabular data layouts, and instant feedback loops.
- **Disciplined Energy:** A deep, carbon-slate canvas punctuated by electric volt accents and surgical emerald completions. The energy is sharp, focused, and deliberate.

## Colors

The palette is engineered exclusively for an immersive, high-contrast dark mode. It anchors on deep carbon and slate neutrals, illuminated by high-voltage functional accents.

### Palette Roles
- **Primary (`#D4FF00` - Electric Volt):** The core active signifier. Reserved strictly for forward momentum: the primary "Start Workout" or "Complete Set" actions, active timer indicators, and current row selections. Never used decoratively or overused on secondary buttons.
- **Secondary (`#22D3EE` - Active Cyan):** Contextual telemetry and active modifications. Highlights inline editable values, cardio pace targets, secondary metrics, and interactive quick-toggles (+30s rest).
- **Tertiary / Success (`#10B981` - Emerald):** Unambiguous verification. Signifies logged sets, completed exercises, and finished sessions. Once tapped, an element transitions from electric volt to emerald, solidifying accomplishment.
- **Neutral Canvas (`#0B0C0E` to `#16181D` - Carbon Slate):** True low-strain dark surfaces that allow high-contrast numbers and typography to punch through cleanly without OLED smear or chromatic aberration.
- **Borders & Dividers (`#262930`):** Subtle structural boundaries that organize dense tabular grids without creating visual clutter.

## Typography

The typography system pairs **Space Grotesk** (display, timers, headers, and numeric readouts) with **Inter** (body, exercise metadata, and instructional tips).

### Typographic Principles
- **Tabular Numerics First:** All weight, rep count, elapsed time, and rest interval readouts utilize tabular numbering (`tnum` OpenType feature). Numbers maintain strict horizontal alignment across multiple sets and history tables without jumping during active timers.
- **Glance Scale Hierarchy:** Primary workout trackers (rest timers and live set counts) use prominent tabular scales (`display-timer` and `data-tabular-lg`), allowing athletes to check time and targets without bringing the phone to eye level.
- **Uppercased Micro-Labels:** Small structural markers (`label-sm` and `label-md`) use uppercase tracking with `Space Grotesk` to provide clear, machine-readable row headers (e.g., `SET`, `PREV`, `LBS / KG`, `REPS`, `REST`).

## Layout & Spacing

Designed fundamentally for mobile portrait orientation with single-handed thumb ergonomics.

### Layout Rules
- **The Lower Third Command Zone:** The primary CTA ("Complete Set", "Start Workout", "Finish Workout") and sticky Rest Timer components sit pinned within the bottom 120px to 180px safe zone of the viewport for effortless thumb reach.
- **Canvas Margins:** Screen gutters stay at a consistent `1.25rem` (20px) on mobile viewports to maximize usable surface area while protecting touch targets from accidental bezel taps.
- **Compact Data Stacking:** Set rows and metrics tables utilize compact vertical spacing (`space-sm` / 12px padding) combined with wide horizontal tap footprints across the full screen width.
- **Safe Area Insets:** Sticky action footers incorporate `env(safe-area-inset-bottom)` with a baseline clearance of at least `1rem` above the home indicator.

## Elevation & Depth

Visual hierarchy is constructed through **tonal stacking and low-contrast perimeter hairlines**, rather than heavy drop shadows. In high-contrast gym lighting, subtle blurred shadows are washed out; solid contrast and boundary definitions provide superior clarity.

### Depth Architecture
1. **Base Floor (`#0B0C0E`):** The master canvas level. Dark, grounding, and non-distracting.
2. **Container Tier (`#16181D` with 1px border `#262930`):** Workout cards, exercise row containers, and history cards. These live directly on the floor with subtle delineation.
3. **Elevated / Focus Tier (`#1E2127` with 1px border `#3A3F4B`):** Active set row in progress, open modal bottom sheets, or active exercise cards.
4. **Floating HUD Tier (`#16181D` at 92% opacity with 16px backdrop-blur and 1px `#3A3F4B` border):** Sticky rest timer bar and bottom action bars that float above scrollable content.
5. **Active Volt Accent Glow:** Reserved strictly for state transitions (e.g., when the rest timer reaches 00:00, or a PR is logged), an instantaneous `0 0 20px rgba(212, 255, 0, 0.25)` flashes to signal immediate tactile feedback.

## Shapes

The design system adopts a **soft-industrial geometry** (roundedness level `1`). Elements feature modest 4px to 8px radiuses, evoking tactical digital instruments, athletic stopwatches, and precision hardware rather than bubbly consumer software.

### Shape Scales
- **Inputs, Buttons, and Table Rows:** `4px` (`0.25rem`) inner radii for compact data elements, checkmark boxes, and inline edit badges.
- **Card Containers and Sheets:** `8px` (`0.5rem`) outer radii for workout modules and floating navigation panels.
- **Timer Badges & Quick Action Chips:** `6px` or subtle rounded rectangles to maintain sharp, functional lines. Full pills are avoided except for status badges.

## Components

### 1. Primary Action Button ("Complete Set" / "Start Workout")
- **Height & Reach:** Fixed 56px minimum height, spanning full width minus canvas margins (`margin-screen`).
- **Styling:** Solid `#D4FF00` background with pure black `#000000` bold Space Grotesk text (`16px`, weight 700). 
- **States:** 
  - *Pressed:* Scales to 98% with an instantaneous darken to `#B8DC00`.
  - *Completed:* Transitions to `#10B981` with white `#FFFFFF` text and a checkmark icon.

### 2. Set Row (Interactive Strength Grid)
- **Layout:** 4-column structured table: `Set #` (36px width), `Previous` (72px, muted text), `Weight × Reps` (Flexible editable fields), `Status Action` (52px width tap target).
- **Default State:** Dark card background `#16181D`, border `#262930`. Numeric text in `#F3F4F6`.
- **Current Active Set:** Outlined with a 1.5px `#D4FF00` border, surface elevated to `#1E2127`. Weight and Reps fields display subtle cyan underlines indicating direct inline editability.
- **Completed Set:** Background dims slightly to `#121316`, numbers turn muted slate `#9CA3AF`, and the check indicator lights up in vibrant emerald `#10B981` with a checked glyph.

### 3. Inline Numeric Input Badges
- **Appearance:** A contained box with a 4px radius, `#1E2127` background, and `#3A3F4B` border.
- **Interaction:** Tapping triggers a dedicated bottom-sheet numeric stepper pad or direct one-touch increment/decrement without opening a disruptive system keyboard.

### 4. Sticky Floating Rest Timer Bar
- **Position:** Pinned 12px above the bottom action button or screen bottom.
- **Surface:** `#16181D` background with 94% opacity, backdrop blur 12px, border 1px solid `#3A3F4B`.
- **Content:** Left side displays "REST" label (`label-sm`, `#9CA3AF`) stacked above large tabular countdown digits (`24px`, `#D4FF00`). Right side features tactile buttons: "+30s" (secondary outline pill) and "Skip" (ghost muted text).
- **Completion Event:** Upon reaching 00:00, the bar pulses electric volt with immediate device haptic feedback.

### 5. Exercise Gallery Card
- **Layout:** Horizontal split tile with a 72×72px desaturated visual thumbnail on the left, and exercise name, target summary (e.g., `4 × 8 · +10 kg`), and status on the right.
- **Completed Exercise:** Thumbnail image drops to 40% opacity, title transitions to `#9CA3AF` with a leading `#10B981` check icon.

### 6. Chips & Selectors
- **Styling:** Low-profile capsules with 1px border (`#262930`), `#16181D` surface, and `#F3F4F6` text. Active filters or workout selectors highlight with a 1px `#D4FF00` border and bold text.